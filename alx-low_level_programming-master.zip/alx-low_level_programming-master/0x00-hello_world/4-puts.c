#include <stdio.h>
/**
 * main - A program that prints a line with puts function
 * Return: 0 (success)
 */
int main(void)
{
	puts("\"Programming is like building a multilingual puzzle");
	return (0);
}
