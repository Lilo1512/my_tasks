6-abs.c
