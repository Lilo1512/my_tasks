#ifndef MAIN_H
#define MAIN_H

int _putchar(char c);

int main(void);

int mul(int a, int b);

void print_number(int n);

void print_numbers(void);

void print_numbers(void);

void print_most_number(void);

void more_numbers(void);

void print_line(int n);

void print_diagonal(int n);

void print_square(int size);

void print_triangle(int size);

int _isupper(int c);

int _isupper(int x);

int _isdigit(int c);

void print_array(int *a, int n);

char *_strcpy(char *dest, char *src);

int _atoi(char *s);

char *_strcat(char *dest, char *src);

char *_strncat(char *dest, char *src, int n);

char *_strncpy(char *dest, char *src, int n);

int _strcmp(char *s1, char *s2);

void reverse_array(int *a, int n);

char *string_toupper(char *);

char *string_toupper(char *str);

char *cap_string(char *);

char *leet (char *str);

char *leet(char *s);

char *rot13(char *);

void print_number(int n);

int _putchar(char c);

char *infinite_add(char *n1, char *n2, char *r, int size_r);

void print_buffer(char *b, int size);

char *add_strings (char *n1, char *n2, char *r, int r_index);

char *_memset(char *s, char b, unsigned int n);

char *_memcpy(char *dest, char *src, unsigned int n);

char *_strchr(char *s, char c);

unsigned int _strspn(char *s, char *accept);

unsigned int i, n, value, check;

char *_strpbrk(char *s, char *accept);

char *_strstr(char *haystack, char *needle);

void print_chessboard(char (*a)[8]);

void print_diagsums(int *a, int size);

void set_string(char **s, char *to);

#endif
