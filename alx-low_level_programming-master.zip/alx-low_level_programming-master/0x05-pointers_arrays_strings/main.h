int _putchar(char c);

int main(void);

int _isupper(int c);

int _isdigit(int c);

int mul(int a, int b);

void print_number(int n);

void print_numbers(void);

void print_numbers(void);

void print_most_number(void);

void more_numbers(void);

void print_line(int n);

void print_diagonal(int n);

void print_square(int size);

void print_triangle(int size);

void print_rev(char *s);

void rev_string(char *s);

void puts2(char *str);

void reset_to_98(int *n);

void puts_half(char *str);

void print_array(int *a, int n);

char *_strcpy(char *dest, char *src);

int _atoi(char *s);
