0x00. C - Hello, World
