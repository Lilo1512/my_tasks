#include <stdio.h>


/**
 * main - 2 print the alphabetic
 * Return: ALways (Success)
 */
int main(void)
{
	char c;

	for (c = 'a'; c <= 'z' ; c++)
	putchar(c);
	putchar('\n');
	return (0);

}
