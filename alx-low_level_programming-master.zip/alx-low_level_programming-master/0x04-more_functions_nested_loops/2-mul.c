#include "main.h"

/**
 * mul -multiplies two integers
 * @x: The first number to multiply
 * @y: The second number to multiply with first number
 * Return: The result of multiplication between x pram and y pram
 */

int mul(int x, int y)

{
	return (x*y);
}
