#ifndef MAIN_H
#define MAIN_H

int _putchar(char c);

int main(void);

int mul(int a, int b);

void print_number(int n);

void print_numbers(void);

void print_numbers(void);

void print_most_number(void);

void more_numbers(void);

void print_line(int n);

void print_diagonal(int n);

void print_square(int size);

void print_triangle(int size);

int _isupper(int c);

int _isupper(int x);

int _isdigit(int c);

void print_array(int *a, int n);

void _puts_recursion(char *s);

void _print_rev_recursion(char *s);

int _strlen_recursion(char *s);

int factorial(int n);

int _pow_recursion(int x, int y);

int _sqrt_recursion(int n);

int _sqrt_recursion(int n);

int is_prime_number(int n);

int is_palindrome(char *s);

int wildcmp(char *s1, char *s2);

#endif
